from typing import List

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma


PERSIST_DIR = "chroma_db"
COLLECTION_NAME = "nestack_documents"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

app = FastAPI(
    title="Nestack PDF Vector Retrieval API",
    version="1.0.0",
)


class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1)
    top_k: int = Field(default=5, ge=1, le=50)


class QueryResult(BaseModel):
    chunk_text: str
    page_number: int
    score: float


def get_vector_store():
    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )

    return Chroma(
        collection_name=COLLECTION_NAME,
        embedding_function=embeddings,
        persist_directory=PERSIST_DIR,
    )


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/query", response_model=List[QueryResult])
def query_documents(request: QueryRequest):
    try:
        vector_store = get_vector_store()
        results = vector_store.similarity_search_with_score(
            request.query,
            k=request.top_k,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Vector store unavailable. Run ingestion first. Error: {exc}",
        )

    response = []

    for document, score in results:
        page = document.metadata.get("page", 0)

        response.append(
            QueryResult(
                chunk_text=document.page_content,
                page_number=int(page) + 1,
                score=float(score),
            )
        )

    return response
