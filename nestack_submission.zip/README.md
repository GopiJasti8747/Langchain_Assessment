# Nestack PDF Vectorisation Pipeline

A LangChain-based PDF ingestion and similarity-search API.

## Architecture

```text
PDF
 │
 ▼
load
(PyPDFLoader)
 │
 ▼
split
(RecursiveCharacterTextSplitter)
 │
 ▼
embed
(HuggingFaceEmbeddings)
 │
 ▼
store
(Chroma persistent vector store)
 │
 ▼
POST /query
similarity_search_with_score()
```

The retrieval endpoint intentionally returns raw chunks. It does not call an LLM and does not use RetrievalQA, ConversationalRetrievalChain, or another pre-built RAG chain.

## Requirements

- Python 3.10+
- pip

## Setup

Create and activate a virtual environment:

### Windows

```powershell
python -m venv .venv
.venv\Scripts\activate
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## 1. Ingest the PDF

The required command format is:

```bash
python ingest.py --file document.pdf
```

Example:

```bash
python ingest.py --file assessment_langchain_vectorization.pdf
```

The first Hugging Face model download can take a little time. After ingestion, a local `chroma_db/` directory is created.

## 2. Start the API

```bash
uvicorn server:app --reload
```

The API will be available at:

```text
http://127.0.0.1:8000
```

Swagger documentation:

```text
http://127.0.0.1:8000/docs
```

## 3. Query the vector store

Request:

```http
POST /query
Content-Type: application/json
```

Body:

```json
{
  "query": "How does the ingestion pipeline work?",
  "top_k": 3
}
```

Example curl:

```bash
curl -X POST "http://127.0.0.1:8000/query" \
  -H "Content-Type: application/json" \
  -d "{\"query\":\"How does the ingestion pipeline work?\",\"top_k\":3}"
```

Response:

```json
[
  {
    "chunk_text": "...",
    "page_number": 1,
    "score": 0.1234
  }
]
```

## Component choices

### Loader: PyPDFLoader

`PyPDFLoader` is used because the input is a PDF and it preserves page-level metadata. The page number is returned by the API as required by the assessment.

### Splitter: RecursiveCharacterTextSplitter

The pipeline uses a chunk size of 800 characters and an overlap of 120 characters.

The 800-character size keeps chunks small enough for focused semantic retrieval while retaining enough surrounding context for meaningful results. The 120-character overlap reduces the chance that useful context is lost at chunk boundaries.

### Embeddings: HuggingFaceEmbeddings

The `sentence-transformers/all-MiniLM-L6-v2` model provides local semantic embeddings without requiring an external API key. This makes the project easy to run locally and reproducibly.

### Vector store: Chroma

Chroma is used as the persistent LangChain-compatible vector store. The embedding collection is saved in the local `chroma_db/` directory.

## Retrieval design

The `/query` endpoint:

1. Creates the same embedding model used during ingestion.
2. Opens the persistent Chroma collection.
3. Calls `similarity_search_with_score()` directly.
4. Returns the raw chunk text, page number, and similarity score.

There is deliberately no LLM call or QA chain.

## LangGraph

LangGraph is not required for correctness, so this implementation keeps ingestion straightforward with ordinary LangChain primitives.

The logical ingestion stages are:

```text
load → split → embed → store
```

## Sample results

`results.json` contains the expected structure for three sample queries. Run ingestion and the API first, then replace the placeholder values with actual returned chunks/scores from the supplied assessment PDF.

## Submission checklist

- [x] Python ingestion script
- [x] LangChain PDF loader
- [x] LangChain text splitter
- [x] LangChain embedding integration
- [x] Persistent vector store
- [x] `/query` HTTP endpoint
- [x] Direct similarity search
- [x] Raw chunk response
- [x] requirements.txt
- [x] README.md
- [x] results.json template

Before submission, create the private GitHub repository requested by the assessment and add the specified evaluator accounts. Do not make the repository public.
