import argparse
import os
import shutil

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma


PERSIST_DIR = "chroma_db"
COLLECTION_NAME = "nestack_documents"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


def load_documents(file_path: str):
    loader = PyPDFLoader(file_path)
    return loader.load()


def split_documents(documents):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=120,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    return splitter.split_documents(documents)


def add_embeddings(documents):
    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )

    # Rebuild the local collection so repeated ingestion does not create duplicates.
    if os.path.exists(PERSIST_DIR):
        shutil.rmtree(PERSIST_DIR)

    vector_store = Chroma(
        collection_name=COLLECTION_NAME,
        embedding_function=embeddings,
        persist_directory=PERSIST_DIR,
    )

    vector_store.add_documents(documents)
    return vector_store


def main():
    parser = argparse.ArgumentParser(description="Ingest a PDF into a persistent Chroma vector store.")
    parser.add_argument("--file", required=True, help="Path to the PDF document")
    args = parser.parse_args()

    if not os.path.isfile(args.file):
        raise FileNotFoundError(f"PDF not found: {args.file}")

    print("[1/3] Loading PDF...")
    documents = load_documents(args.file)
    print(f"Loaded {len(documents)} page documents.")

    print("[2/3] Splitting document...")
    chunks = split_documents(documents)
    print(f"Created {len(chunks)} chunks.")

    print("[3/3] Embedding and storing...")
    add_embeddings(chunks)
    print(f"Vector store persisted to: {PERSIST_DIR}/")
    print("Ingestion completed successfully.")


if __name__ == "__main__":
    main()
